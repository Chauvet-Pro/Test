from tkinter import *
from tkinter import filedialog
from openpyxl import load_workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.utils import get_column_letter
import pandas as pd


def create_chart(File, save_as=None):
    # Load the workbook and worksheet
    wb = load_workbook(File)
    ws = wb.active

    # Insert a new column for row numbers at the beginning of the sheet
    ws.insert_cols(1)
    for i in range(2, ws.max_row + 1):  # Starting from row 2 to avoid the header
        ws.cell(row=i, column=1, value=i - 1)  # Row numbers start from 1

    # Read the data into a pandas DataFrame, accounting for the new row numbers column
    df = pd.read_excel(File, sheet_name='Sheet', header=[0, 1])

    # Get unique 'Curve' categories from the first level of the header
    unique_curve_categories = df.columns.get_level_values(0).unique()

    # Calculate the start and end indices for each 'Curve' section
    curve_sections = {}
    for category in unique_curve_categories:
        if 'Curve' in category:
            curve_sections[category] = [None, None]

    for col_index, (category, _) in enumerate(df.columns):
        if category in curve_sections:
            if curve_sections[category][0] is None:
                curve_sections[category][0] = col_index
            curve_sections[category][1] = col_index

    # Get the last row of the data
    last_row = df.shape[0] + 2  # Since the header is two rows

    # Create a line chart for each 'Curve' section
    for category, (start_index, end_index) in curve_sections.items():
        # Create a LineChart object
        chart = LineChart()
        chart.title = category

        # Add data to the chart (Y values)
        # Include the second row for the legend labels
        data = Reference(ws, min_col=start_index + 2, min_row=2, max_col=end_index + 2, max_row=last_row)
        chart.add_data(data, titles_from_data=True)

        # Set the categories (X-axis labels - row numbers)
        cats = Reference(ws, min_col=1, min_row=3, max_row=last_row)
        chart.set_categories(cats)

        # Add the chart to the worksheet under the last row of each 'Curve' section
        chart_position = f"{get_column_letter(start_index + 2)}{last_row + 2}"  # Place the chart 2 rows below the last row
        ws.add_chart(chart, chart_position)

    # Determine the filename for saving using a Tkinter file dialog
    if not save_as:
        root = Tk()
        root.withdraw()  # Hide the main window
        save_as = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel Files", "*.xlsx")])
        root.destroy()  # Close the hidden Tkinter window

    # Save the workbook with the specified filename
    if save_as:
        wb.save(save_as)

# Example usage:
# create_chart("input.xlsx")  # Use the Tkinter file dialog to save the file
